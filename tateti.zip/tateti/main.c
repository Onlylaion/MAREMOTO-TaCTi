#include "header.h"

int main(){

    char tablero[TAM][TAM];
    int fila, columna;
    char turno = 'X';
    char ganador = ' ';
    int movimientos = 0;

    inicializarTablero(tablero);
    srand(time(NULL));

    while(ganador == ' ' && movimientos < TAM * TAM){

        mostrarTablero(tablero);

        if (turno == 'X') {

            printf("Turno del jugador %c. Ingrese fila y columna (1-3): ", turno);
            scanf("%d %d", &fila, &columna);
            fila--;
            columna--;

            if (realizarMovimiento(tablero, fila, columna, turno)) {
                movimientos++;
                ganador = verificarGanador(tablero);
                turno = 'O';
            } else {
                printf("Movimiento inv�lido, intente de nuevo.\n");
            }

        } else {

            printf("Turno de la IA (O)...\n");
            movimientoIA(tablero);
            movimientos++;
            ganador = verificarGanador(tablero);
            turno = 'X';

        }
    }

    mostrarTablero(tablero);
    if (ganador != ' ') {
        printf("�El jugador %c gana!\n", ganador);
    } else {
        printf("�Es un empate!\n");
    }

    return 0;
}



