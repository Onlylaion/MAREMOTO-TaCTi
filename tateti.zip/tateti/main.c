#include "header.h"

int main(){

    char tablero[TAM][TAM];
    int fila, columna;
    char jugador, ia;
    char turno;
    char ganador = ' ';
    int movimientos = 0;

    inicializarTablero(tablero);
    srand(time(NULL));

    // asignar "X" y "O" aleatorio
    if (rand() % 2 == 0) {
        jugador = 'X';
        ia = 'O';
    } else {
        jugador = 'O';
        ia = 'X';
    }

    turno = 'X';

    while(ganador == ' ' && movimientos < TAM*TAM){

        actualizarPantalla(tablero, jugador, ia);

        if (turno == jugador) {

            printf("Turno del jugador (%c). Ingrese fila y columna (1-3): ", jugador);
            scanf("%d %d", &fila, &columna);
            fila--;
            columna--;

            if (realizarMovimiento(tablero, fila, columna, turno)) {
                movimientos++;
                ganador = verificarGanador(tablero);
                turno = ia;
            } else {
                printf("Movimiento inv�lido, intente de nuevo.\n");
            }

        } else {

            printf("Turno de la IA (%c)...\n", ia);
            movimientoIA(tablero, ia);
            movimientos++;
            ganador = verificarGanador(tablero);
            turno = jugador;

        }
    }

    actualizarPantalla(tablero, jugador, ia);

    if (ganador != ' ') {
        printf("El jugador %c gana!\n", ganador);
    } else {
        printf("Es un empate!\n");
    }

    return 0;
}



