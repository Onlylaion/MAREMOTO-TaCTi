#include "header.h"

void inicializarTablero(char tablero[TAM][TAM]) {

    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            tablero[i][j] = ' ';
        }
    }

    return;
}

void mostrarTablero(char tablero[TAM][TAM]) {

    printf("\n");
    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            printf(" %c ", tablero[i][j]);
            if (j < TAM - 1) printf("|");
        }
        printf("\n");
        if (i < TAM - 1) printf("-----------\n");
    }
    printf("\n");

    return;
}

int realizarMovimiento(char tablero[TAM][TAM], int fila, int columna, char jugador) {

    if (fila>=0 && fila<TAM && columna>=0 && columna<TAM && tablero[fila][columna] == ' ') {
        tablero[fila][columna] = jugador;
        return 1;
    }

    return 0;
}

char verificarGanador(char tablero[TAM][TAM]) {

    // verifica horizontal y vertical
    for(int i = 0; i < TAM; i++){
        if (tablero[i][0] != ' ' && tablero[i][0] == tablero[i][1] && tablero[i][1] == tablero[i][2]) return tablero[i][0];
        if (tablero[0][i] != ' ' && tablero[0][i] == tablero[1][i] && tablero[1][i] == tablero[2][i]) return tablero[0][i];
    }

    // verifica diagonales
    if (tablero[0][0] != ' ' && tablero[0][0] == tablero[1][1] && tablero[1][1] == tablero[2][2]) return tablero[0][0];
    if (tablero[0][2] != ' ' && tablero[0][2] == tablero[1][1] && tablero[1][1] == tablero[2][0]) return tablero[0][2];

    return ' ';
}

void movimientoIA(char tablero[TAM][TAM], char ia) {

    int fila, columna;

    if (puedeGanar(tablero, 'O', &fila, &columna) || puedeGanar(tablero, 'X', &fila, &columna)) {
        tablero[fila][columna] = ia;
        return;
    }

    do {
        fila = rand() % TAM;
        columna = rand() % TAM;
    } while (tablero[fila][columna] != ' ');

    tablero[fila][columna] = ia;

    return;
}

int puedeGanar(char tablero[TAM][TAM], char jugador, int* fila, int* columna) {

    for (int i = 0; i < TAM; i++) {

        for (int j = 0; j < TAM; j++) {

            if (tablero[i][j] == ' ') {

                tablero[i][j] = jugador;

                if (verificarGanador(tablero) == jugador) {
                    *fila = i;
                    *columna = j;
                    tablero[i][j] = ' ';
                    return 1;
                }

                tablero[i][j] = ' ';
            }
        }
    }

    return 0;
}

void actualizarPantalla(char tablero[TAM][TAM], char jugador, char ia){

    system("cls");
    printf("Jugador: %c | IA: %c\n", jugador, ia);
    mostrarTablero(tablero);

    return;
}
























