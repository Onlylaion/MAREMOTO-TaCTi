#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TAM 3

void inicializarTablero(char tablero[TAM][TAM]);
void mostrarTablero(char tablero[TAM][TAM]);
int realizarMovimiento(char tablero[TAM][TAM], int fila, int columna, char jugador);
char verificarGanador(char tablero[TAM][TAM]);
void movimientoIA(char tablero[TAM][TAM]);
int puedeGanar(char tablero[TAM][TAM], char jugador, int *fila, int *columna);

#endif // HEADER_H_INCLUDED
