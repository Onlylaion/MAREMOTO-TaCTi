#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include <string.h>
#include "Juego.h"
#include "TDALista.h"


int obtenerDatosArchConfiguracion(char* ruta, tConfiguracion* configuracion)
{
    char cadena[TAM_CADENA_ARCH];
    FILE* arch = fopen(ruta,"rt");
    if(!arch)
        return ERROR_ARCH;

    fgets(cadena,TAM_CADENA_ARCH,arch);
    sscanf(cadena,"%[^|]|%[^\n]",configuracion->urlApi,configuracion->codIdenGrupo);
    fgets(cadena,TAM,arch);
    sscanf(cadena,"%d",&configuracion->CantPartidas);
    fclose(arch);

    return TODO_OK;
}

void ejecucionDelJugador(char tablero[][3], char letra){

    HANDLE hIn = GetStdHandle(STD_INPUT_HANDLE);
    DWORD eventos;
    INPUT_RECORD ir;

    // Habilita la captura de eventos de mouse
    SetConsoleMode(hIn, ENABLE_EXTENDED_FLAGS | ENABLE_MOUSE_INPUT);

    while (1) {
        ReadConsoleInput(hIn, &ir, 1, &eventos);
        // Si se detecta un evento de mouse y se presiona el bot�n izquierdo
        if (ir.EventType == MOUSE_EVENT && ir.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
        {
            int x = ir.Event.MouseEvent.dwMousePosition.X;
            int y = ir.Event.MouseEvent.dwMousePosition.Y;

            if(registrarMovEnTablero(tablero,letra, x, y))
            {
                system("cls");
                fflush(stdout);
                Sleep(10);
                return;
            }
            else
            {
                printf("Error al realizar el movimiento.\n");
                Sleep(100);
                fflush(stdout);
            }
        }
    }
}

int registrarMovEnTablero(char tablaTaTeTi[][3], char letra, int x, int y){

    if(x>=12 && x<=17 && y>=3 && y<=7)
        return tablaTaTeTi[0][0]==' ' ? (tablaTaTeTi[0][0]=letra) : 0;
    else if(x>=19 && x<=25 && y>=3 && y<=7)
        return tablaTaTeTi[0][1]==' ' ? (tablaTaTeTi[0][1]=letra) : 0;
    else if(x>=27 && x<=33 && y>=3 && y<=7)
        return tablaTaTeTi[0][2]==' ' ? (tablaTaTeTi[0][2]=letra) : 0;
    else if(x>=12 && x<=17 && y>=8 && y<=12)
        return tablaTaTeTi[1][0]==' ' ? (tablaTaTeTi[1][0]=letra) : 0;
    else if(x>=19 && x<=25 && y>=8 && y<=12)
        return tablaTaTeTi[1][1]==' ' ? (tablaTaTeTi[1][1]=letra) : 0;
    else if(x>=27 && x<=33 && y>=8 && y<=12)
        return tablaTaTeTi[1][2]==' ' ? (tablaTaTeTi[1][2]=letra) : 0;
    else if(x>=12 && x<=17 && y>=14 && y<=17)
        return tablaTaTeTi[2][0]==' ' ? (tablaTaTeTi[2][0]=letra) : 0;
    else if(x>=19 && x<=25 && y>=14 && y<=17)
        return tablaTaTeTi[2][1]==' ' ? (tablaTaTeTi[2][1]=letra) : 0;
    else if(x>=27 && x<=33 && y>=14 && y<=17)
        return tablaTaTeTi[2][2]==' ' ? (tablaTaTeTi[2][2]=letra) : 0;
    return 0;
}

int menu(){
    char opcion;
    do
    {
        printf(" [A] Jugar\n [B] Ver ranking equipo\n [C] Salir\n ");
        scanf("%c",&opcion);
        fflush(stdin);
        system("cls");

        if(opcion!='A'&&opcion!='B'&&opcion!='C')
        {
            printf("\n Opcion ingresada incorrecta \n");
        }
        else
        {
            switch(opcion)
            {
            case 'A':
                {
                    return 1;
                }
            case 'B':
                {
                    return 1;
                }
            case 'C':
                return 0;
            }
        }

    }
    while(opcion!='A'&&opcion!='B'&&opcion!='C');

    return 0;
}

void mostrarEnOrdenJugadores(tLista* jugadores)
{
    int i=1;

    printf("Orden de Juego:\n");
    while(*jugadores)
    {
        printf("%d-%s\n",i,((tJugador*)(*jugadores)->info)->nombre);
        i++;
        jugadores=&(*jugadores)->sig;
    }
    printf("\nPresione enter para comenzar el juego...");
    fflush(stdin);
    getchar();
}

void inicializarTablero(char tablero[TAM][TAM]) {

    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            tablero[i][j] = ' ';
        }
    }

}

void mostrarTablero(char tablero[TAM][TAM]) {
    printf("\n\n\n");

    for (int i = 0; i < TAM; i++) {
        // Imprime las filas del tablero
        for (int fila = 0; fila < 4; fila++) {
            printf("           "); // Espaciado para centrar el tablero

            for (int j = 0; j < TAM; j++) {
                if (fila == 2)
                    printf("   %c   ", tablero[i][j]);
                else
                    printf("       ");

                if (j < TAM - 1) printf("|");  // Separadores verticales
            }
            printf("\n");
        }

        // linea horizontal
        if (i < TAM - 1)
            printf("           =======|=======|=======\n");
    }
}

char verificarGanador(char tablero[TAM][TAM]) {

    // verifica horizontal y vertical
    for(int i = 0; i < TAM; i++){
        if (tablero[i][0] != ' ' && tablero[i][0] == tablero[i][1] && tablero[i][1] == tablero[i][2]) return tablero[i][0];
        if (tablero[0][i] != ' ' && tablero[0][i] == tablero[1][i] && tablero[1][i] == tablero[2][i]) return tablero[0][i];
    }

    // verifica diagonales
    if (tablero[0][0] != ' ' && tablero[0][0] == tablero[1][1] && tablero[1][1] == tablero[2][2]) return tablero[0][0];
    if (tablero[0][2] != ' ' && tablero[0][2] == tablero[1][1] && tablero[1][1] == tablero[2][0]) return tablero[0][2];

    return ' ';
}

void movimientoIA(char tablero[TAM][TAM], char letra) {

    int fila, columna;

    if (puedeGanar(tablero, 'O', &fila, &columna) || puedeGanar(tablero, 'X', &fila, &columna)) {
        tablero[fila][columna] = letra;
        return;
    }

    do {
        fila = rand() % TAM;
        columna = rand() % TAM;
    } while (tablero[fila][columna] != ' ');

    tablero[fila][columna] = letra;

    return;
}

int puedeGanar(char tablero[TAM][TAM], char jugador, int* fila, int* columna){

    for (int i = 0; i < TAM; i++) {

        for (int j = 0; j < TAM; j++) {

            if (tablero[i][j] == ' ') {

                tablero[i][j] = jugador;

                if (verificarGanador(tablero) == jugador) {
                    *fila = i;
                    *columna = j;
                    tablero[i][j] = ' ';
                    return 1;
                }

                tablero[i][j] = ' ';
            }
        }
    }

    return 0;
}

char quienEmpieza(){
    srand(time(NULL));
    if(rand()%2 == 1)
        return 'X';
    else
        return 'O';
}

void actualizarPantalla(char tablero[TAM][TAM], char jugador, char ia){

    system("cls");
    printf("Jugador: %c | IA: %c\n", jugador, ia);
    mostrarTablero(tablero);

    return;
}

void ingresarJugadores(tLista* pl){
    tJugador jugador;
    int cantidad=0;

    printf("Ingresar Nombres(termina con FIN/fin):\n");
    scanf("%s",jugador.nombre);
    jugador.puntaje=0;

    while(strcmpi(jugador.nombre,"FIN")!=0)
    {
        listaInsertarEnPosAleatoria(pl,cantidad,&jugador,sizeof(jugador));
        cantidad++;
        scanf("%s",jugador.nombre);
        jugador.puntaje=0;
    }
    system("cls");
}
void quienGana(tNodo* listaJugadores,char ganador,char turnoJugador)
{
    tJugador* jugador = (tJugador*)listaJugadores->info;
    if (ganador == turnoJugador ) {
    printf("El jugador %s gana!!\n", jugador->nombre);
    jugador->puntaje +=3;
    }
    else if(ganador!=' ')
    {
        printf("La IA gana!!\n");
        jugador->puntaje -=1;
    }
    else
    {
        printf("Es un empate!!\n");
        jugador->puntaje +=2;
    }
}
int Jugar(char tablero[][3],tLista* listaJugadores, tConfiguracion* configuracion){
    char ganador = ' ';
    int movimientos = 0, partidas = 0;
    char turnoJugador;
    tNodo* jugadores = *listaJugadores;


    while(jugadores)
    {


        while(partidas<2)
        {
            turnoJugador=quienEmpieza();

            while(ganador == ' ' && movimientos < TAM * TAM)
            {

                    if(turnoJugador == 'X')
                    {
                        actualizarPantalla(tablero,'X','O');
                        ejecucionDelJugador(tablero,'X');
                        movimientos++;
                        ganador = verificarGanador(tablero);

                        if(ganador==' ' && movimientos<TAM*TAM)
                        {
                            movimientoIA(tablero,'O');
                            movimientos++;
                            ganador = verificarGanador(tablero);
                        }
                    }
                    else
                    {
                        movimientoIA(tablero,'X');
                        movimientos++;
                        ganador = verificarGanador(tablero);
                        actualizarPantalla(tablero,'O','X');

                        if(ganador==' '&& movimientos<TAM*TAM)
                        {
                            ejecucionDelJugador(tablero,'O');
                            movimientos++;
                            ganador = verificarGanador(tablero);
                        }
                    }
            }

            actualizarPantalla(tablero,turnoJugador=='X'?'X':'O',turnoJugador!='X'?'O':'X');
            quienGana(jugadores,ganador,turnoJugador);

            printf("\nPresione enter para comenzar el siguiente juego...");
            fflush(stdin);

            getchar();


            ganador=' ';
            movimientos=0;
            partidas++;
            inicializarTablero(tablero);
        }
        jugadores=jugadores->sig;
        partidas=0;
    }

    return 0;
}

