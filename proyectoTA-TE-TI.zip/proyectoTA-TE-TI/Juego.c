#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include "Juego.h"

void ejecucionDelJugador(char tablero[][3], char letra)
{
    HANDLE hIn = GetStdHandle(STD_INPUT_HANDLE);
    DWORD eventos;
    INPUT_RECORD ir;

    // Habilita la captura de eventos de mouse
    SetConsoleMode(hIn, ENABLE_EXTENDED_FLAGS | ENABLE_MOUSE_INPUT);

    while (1) {
        ReadConsoleInput(hIn, &ir, 1, &eventos);
        // Si se detecta un evento de mouse y se presiona el bot�n izquierdo
        if (ir.EventType == MOUSE_EVENT && ir.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
        {
            int x = ir.Event.MouseEvent.dwMousePosition.X;
            int y = ir.Event.MouseEvent.dwMousePosition.Y;

            if(registrarMovEnTablero(tablero,letra, x, y))
            {
                system("cls");
                fflush(stdout);
                Sleep(10);
                mostrarTablero(tablero);
                return;
            }
            else
            {
                printf("Error al realizar el movimiento.\n");
                Sleep(10);
                fflush(stdout);
            }
        }
    }
}
int registrarMovEnTablero(char tablaTaTeTi[][3], char letra, int x, int y)
{

    if(x>=12 && x<=17 && y>=3 && y<=7)
        return tablaTaTeTi[0][0]==' ' ? (tablaTaTeTi[0][0]=letra) : 0;
    else if(x>=19 && x<=25 && y>=3 && y<=7)
        return tablaTaTeTi[0][1]==' ' ? (tablaTaTeTi[0][1]=letra) : 0;
    else if(x>=27 && x<=33 && y>=3 && y<=7)
        return tablaTaTeTi[0][2]==' ' ? (tablaTaTeTi[0][2]=letra) : 0;
    else if(x>=12 && x<=17 && y>=8 && y<=12)
        return tablaTaTeTi[1][0]==' ' ? (tablaTaTeTi[1][0]=letra) : 0;
    else if(x>=19 && x<=25 && y>=8 && y<=12)
        return tablaTaTeTi[1][1]==' ' ? (tablaTaTeTi[1][1]=letra) : 0;
    else if(x>=27 && x<=33 && y>=8 && y<=12)
        return tablaTaTeTi[1][2]==' ' ? (tablaTaTeTi[1][2]=letra) : 0;
    else if(x>=12 && x<=17 && y>=14 && y<=17)
        return tablaTaTeTi[2][0]==' ' ? (tablaTaTeTi[2][0]=letra) : 0;
    else if(x>=19 && x<=25 && y>=14 && y<=17)
        return tablaTaTeTi[2][1]==' ' ? (tablaTaTeTi[2][1]=letra) : 0;
    else if(x>=27 && x<=33 && y>=14 && y<=17)
        return tablaTaTeTi[2][2]==' ' ? (tablaTaTeTi[2][2]=letra) : 0;
    return 0;
}
int menu()
{
    char opcion;
    do
    {
        printf(" [A] Jugar\n [B] Ver ranking equipo\n [C] Salir\n ");
        scanf("%c",&opcion);
        fflush(stdin);
        system("cls");

        if(opcion!='A'&&opcion!='B'&&opcion!='C')
        {
            printf("\n Opcion ingresada incorrecta \n");
        }
        else
        {
            switch(opcion)
            {
            case 'A':
                {
                    return 1;
                }
            case 'B':
                {
                    return 1;
                }
            case 'C':
                return 0;
            }
        }

    }
    while(opcion!='A'&&opcion!='B'&&opcion!='C');

    return 0;
}


void inicializarTablero(char tablero[TAM][TAM]) {

    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            tablero[i][j] = ' ';
        }
    }

}

void mostrarTablero(char tablero[TAM][TAM]) {
    printf("\n\n\n");

    for (int i = 0; i < TAM; i++) {
        // Imprime las filas del tablero
        for (int fila = 0; fila < 4; fila++) {
            printf("           "); // Espaciado para centrar el tablero

            for (int j = 0; j < TAM; j++) {
                if (fila == 2)
                    printf("   %c   ", tablero[i][j]);
                else
                    printf("       ");

                if (j < TAM - 1) printf("|");  // Separadores verticales
            }
            printf("\n");
        }

        // linea horizontal
        if (i < TAM - 1)
            printf("           =======|=======|=======\n");
    }
}

char verificarGanador(char tablero[TAM][TAM]) {

    // verifica horizontal y vertical
    for(int i = 0; i < TAM; i++){
        if (tablero[i][0] != ' ' && tablero[i][0] == tablero[i][1] && tablero[i][1] == tablero[i][2]) return tablero[i][0];
        if (tablero[0][i] != ' ' && tablero[0][i] == tablero[1][i] && tablero[1][i] == tablero[2][i]) return tablero[0][i];
    }

    // verifica diagonales
    if (tablero[0][0] != ' ' && tablero[0][0] == tablero[1][1] && tablero[1][1] == tablero[2][2]) return tablero[0][0];
    if (tablero[0][2] != ' ' && tablero[0][2] == tablero[1][1] && tablero[1][1] == tablero[2][0]) return tablero[0][2];

    return ' ';
}

void movimientoIA(char tablero[TAM][TAM], char letra) {

    int fila, columna;

    if (puedeGanar(tablero, 'O', &fila, &columna) || puedeGanar(tablero, 'X', &fila, &columna)) {
        tablero[fila][columna] = letra;
        return;
    }

    do {
        fila = rand() % TAM;
        columna = rand() % TAM;
    } while (tablero[fila][columna] != ' ');

    tablero[fila][columna] = letra;

    return;
}

int puedeGanar(char tablero[TAM][TAM], char jugador, int* fila, int* columna) {

    for (int i = 0; i < TAM; i++) {

        for (int j = 0; j < TAM; j++) {

            if (tablero[i][j] == ' ') {

                tablero[i][j] = jugador;

                if (verificarGanador(tablero) == jugador) {
                    *fila = i;
                    *columna = j;
                    tablero[i][j] = ' ';
                    return 1;
                }

                tablero[i][j] = ' ';
            }
        }
    }

    return 0;
}
int quienEmpieza()
{
    srand(time(NULL));
    if(rand()%2 == 1)
        return 1;
    else
        return 0;
}
void actualizarPantalla(char tablero[TAM][TAM], char jugador, char ia){

    system("cls");
    printf("Jugador: %c | IA: %c\n", jugador, ia);
    mostrarTablero(tablero);

    return;
}
int Jugar(char tablero[][3])
{
    char ganador = ' ';
    int movimientos = 0;
    int turnoDelJugador= quienEmpieza();

    while(ganador == ' ' && movimientos < TAM * TAM){
        if(turnoDelJugador)
        {
            actualizarPantalla(tablero,'X','O');
            ejecucionDelJugador(tablero,'X');
            movimientos++;
            ganador = verificarGanador(tablero);

            if(ganador==' '&& movimientos<9)
            {
                movimientoIA(tablero,'O');
                movimientos++;
                ganador = verificarGanador(tablero);
            }
        }
        else
        {
            movimientoIA(tablero,'X');
            movimientos++;
            ganador = verificarGanador(tablero);
            actualizarPantalla(tablero,'X','O');

            if(ganador==' '&& movimientos<9)
            {
                ejecucionDelJugador(tablero,'O');
                movimientos++;
                ganador = verificarGanador(tablero);
            }
        }
        system("cls");
    }

    actualizarPantalla(tablero,'X','O');
    if (ganador != ' ') {
        printf("El jugador %c gana!!\n", ganador);
    } else {
        printf("Es un empate!\n");
    }

    return 0;
}

