#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "TDALista.h"

void listaCrear(tLista * l)
{
    *l = NULL;
}

void listaInsertarAlInicio(tLista *l,void* elem, unsigned tamElem)
{
    tNodo* newNodo;

    newNodo= malloc(sizeof(tNodo));
    if(!newNodo)
        return;
    newNodo->info = malloc(tamElem);
    if(!newNodo->info)
    {
        free(newNodo);
        return;
    }
    newNodo->tamInfo=tamElem;
    memcpy(newNodo->info,elem,tamElem);

    newNodo->sig=*l;
    *l=newNodo;
}

void listaInsertarEnPosAleatoria(tLista* l, int limite, void* elem, unsigned tamElem)
{

    tNodo* newNodo;
    int n, i=0;

    newNodo= malloc(sizeof(tNodo));
    if(!newNodo)
        return;
    newNodo->info = malloc(tamElem);
    if(!newNodo->info)
    {
        free(newNodo);
        return;
    }
    newNodo->tamInfo=tamElem;
    memcpy(newNodo->info,elem,tamElem);

    if(!*l)
    {
        newNodo->sig=*l;
        *l=newNodo;
        return;
    }

    srand(time(NULL));

    n= rand()%(limite+1);


    while(i< n && (*l)->sig)
    {
        l = &(*l)->sig;
        i++;
    }
    newNodo->sig= *l;
    *l = newNodo;
}
