#ifndef TDALISTA_H_INCLUDED
#define TDALISTA_H_INCLUDED

typedef struct sNodo
{
    void* info;
    unsigned tamInfo;
    struct sNodo *sig;
}tNodo;

typedef tNodo* tLista;
void listaInsertarAlInicio(tLista *l,void* elem, unsigned tamElem);
void listaInsertarEnPosAleatoria(tLista* l, int limite, void* elem, unsigned tamElem);
#endif // TDALISTA_H_INCLUDED
