#ifndef JUEGO_H_INCLUDED
#define JUEGO_H_INCLUDED

#define TAM 3
typedef struct
{
    char codigoGrupo[20];
    char nombre[20];
    int puntaje;
}tJugador;


void inicializarTablero(char tablero[TAM][TAM]);
void mostrarTablero(char tablero[TAM][TAM]);
char verificarGanador(char tablero[TAM][TAM]);
void movimientoIA(char tablero[TAM][TAM], char letra);
int puedeGanar(char tablero[TAM][TAM], char jugador, int *fila, int *columna);
int Jugar(char tablero[][3]);
void actualizarPantalla(char tablero[TAM][TAM], char jugador, char ia);


///ESTO ES DE PRUEBA:
void ejecucionDelJugador(char tablero[][3], char letra);
int registrarMovEnTablero(char tablaTaTeTi[][3], char letra, int x, int y);
int menu();
int quienEmpieza();
#endif // JUEGO_H_INCLUDED
