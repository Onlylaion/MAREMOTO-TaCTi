#ifndef JUEGO_H_INCLUDED
#define JUEGO_H_INCLUDED
#include "TDALista.h"
#define TAM 3
#define TAM_URL 50
#define TAM_CADENA_ARCH 100
#define TAM_CADENA 20
#define ARCHIVO_CONFIG 1

typedef struct
{
    char nombre[TAM_CADENA];
    char letra;
    int puntaje;

}tJugador;

typedef struct
{
    char jugador;
    int puntajeObtenido;
    char tablero[TAM][TAM];

}tPartida;

typedef struct
{
    char urlApi[TAM_URL];
    char codIdenGrupo[TAM_CADENA];
    int CantPartidas;

}tConfiguracion;

void inicializarTablero(char tablero[TAM][TAM]);
void mostrarTablero(char tablero[TAM][TAM]);
char verificarGanador(char tablero[TAM][TAM]);
void movimientoIA(char tablero[TAM][TAM], char letra);
int puedeGanar(char tablero[TAM][TAM], char jugador, int *fila, int *columna);
void actualizarPantalla(char tablero[TAM][TAM], char jugador, char ia);
char quienEmpieza();
void ejecucionDelJugador(char tablero[TAM][TAM], char letra);
int registrarMovEnTablero(char tablaTaTeTi[TAM][TAM], char letra, int x, int y);
void mostrarEnOrdenJugadores(tLista* jugadores);
void quienGana(tNodo* listaJugadores,char ganador,char turnoJugador);

///ESTO ES DE PRUEBA:
int menu();
int Jugar(char tablero[TAM][TAM],tLista* listaJugadores, tConfiguracion* configuracion);
void ingresarJugadores(tLista* pl);
int obtenerDatosArchConfiguracion(char* ruta, tConfiguracion* configuracion);
#endif // JUEGO_H_INCLUDED
