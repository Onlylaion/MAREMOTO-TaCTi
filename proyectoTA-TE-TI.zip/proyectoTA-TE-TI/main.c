#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "Juego.h"




int main()
{

    char tablero[TAM][TAM];
    inicializarTablero(tablero);
    Jugar(tablero);

}






