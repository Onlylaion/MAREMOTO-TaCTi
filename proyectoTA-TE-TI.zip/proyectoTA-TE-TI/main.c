#include "Juego.h"
#include "TDALista.h"
#include "conectarApi.h"


int main(int arg,char** arg2)
{

    char tablero[TAM][TAM];
    tLista listaJugadores;
    tConfiguracion configuracion;

    if(arg!=2)
        return ERROR;

    listaCrear(&listaJugadores);
    inicializarTablero(tablero);
    obtenerDatosArchConfiguracion(arg2[ARCHIVO_CONFIG],&configuracion);
    ingresarJugadores(&listaJugadores);
    mostrarEnOrdenJugadores(&listaJugadores);
    Jugar(tablero,&listaJugadores,&configuracion);

}






